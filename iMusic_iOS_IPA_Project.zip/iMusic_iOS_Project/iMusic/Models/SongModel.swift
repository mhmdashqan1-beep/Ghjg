import Foundation

struct LyricLine: Identifiable, Codable, Equatable {
    var id = UUID()
    let time: TimeInterval
    let text: String
    let pronunciation: String
    let translation: String
}

struct SongItem: Identifiable, Codable, Equatable {
    let id: String
    let title: String
    let artist: String
    let album: String
    let duration: TimeInterval
    let artworkName: String
    let remoteArtworkURL: String?
    let previewAudioURL: String?
    let bpm: Double
    let primaryColorHex: String
    let secondaryColorHex: String
    var lyrics: [LyricLine]
}

final class MusicCatalog {
    static let shared = MusicCatalog()

    let builtInSongs: [SongItem] = [
        SongItem(
            id: "nasseeny_leih",
            title: "Nasseeny Leih",
            artist: "Tamer Hosny",
            album: "Eish Besho'ak",
            duration: 248,
            artworkName: "tamer_nasseeny.jpg",
            remoteArtworkURL: nil,
            previewAudioURL: nil,
            bpm: 96,
            primaryColorHex: "#3C464F",
            secondaryColorHex: "#1E2229",
            lyrics: [
                LyricLine(time: 0, text: "♪ مقدمة موسيقية - تامر حسني ♪", pronunciation: "Moqaddima Mousiqia", translation: "♪ Instrumental Intro ♪"),
                LyricLine(time: 8, text: "أول يوم فراق عدا عليا كأنه سنة", pronunciation: "Awwal youm feraq 'adda 'alaya ka'enno sana", translation: "The first day of separation passed like a whole year"),
                LyricLine(time: 16, text: "بفكر فيك ومش قادر أنسى اللي بينا هنا", pronunciation: "Bafakkar feek w mesh 'ader ansa elli benna hena", translation: "Thinking of you and unable to forget what we shared"),
                LyricLine(time: 24, text: "أنا مقدرش أبعد ثانية", pronunciation: "Ana ma'darsh ab'ed sanya", translation: "I cannot stay away for a single second"),
                LyricLine(time: 30, text: "أنا بعدك مليش في الدنيا", pronunciation: "Ana ba'dak maleesh fel donya", translation: "Without you I have nothing in this world"),
                LyricLine(time: 36, text: "يا أول حب عاش قلبي معاه", pronunciation: "Ya awwal hob 'ash 'albi ma'ah", translation: "O first love my heart ever lived with"),
                LyricLine(time: 41, text: "الأيام بقت مش هي", pronunciation: "El-ayyam ba'et mesh heya", translation: "The days are no longer the same"),
                LyricLine(time: 44, text: "ياريت ترجع وحشت عينيا", pronunciation: "Yareet terga' wahasht 'einaya", translation: "I wish you'd return, my eyes miss you so much"),
                LyricLine(time: 48, text: "حياتي في بعدك انت مش حياة", pronunciation: "Hayati fi bo'dak enta mesh hayah", translation: "My life away from you is not a life at all"),
                LyricLine(time: 54, text: "ناسيني ليه؟ بتتعب قلبي وياك", pronunciation: "Nasseeny leih? Betet'eb 'albi wayyak", translation: "Why have you forgotten me? You weary my heart with you"),
                LyricLine(time: 61, text: "ده ميهونش أبداً عليا أنساك، آه", pronunciation: "Da mayhoonsh abadan 'alaya ansak, ah", translation: "I could never bear to forget you, oh"),
                LyricLine(time: 68, text: "تعالى لومني ريح قلبي وارتاح", pronunciation: "Ta'ala lomni rayyah 'albi w ertah", translation: "Come blame me, ease my heart and find peace"),
                LyricLine(time: 75, text: "تعالى ياللي نفسي في حضنك أرتاح", pronunciation: "Ta'ala yalli nefsi fi hodnak artah", translation: "Come, you in whose embrace I long to rest")
            ]
        ),
        SongItem(
            id: "fatet_sineen",
            title: "Fatet Sineen",
            artist: "Elissa",
            album: "Bastanak",
            duration: 242,
            artworkName: "elissa_fatet_sineen.jpg",
            remoteArtworkURL: nil,
            previewAudioURL: nil,
            bpm: 90,
            primaryColorHex: "#4A5A67",
            secondaryColorHex: "#202A33",
            lyrics: [
                LyricLine(time: 0, text: "♪ فاتت سنين - إليسا ♪", pronunciation: "Fatet Sineen - Elissa", translation: "♪ Years Have Passed - Elissa ♪"),
                LyricLine(time: 6, text: "فاتت سنين وأنا بسمعك ولا عمري جيت على بالك", pronunciation: "Fatet sineen wana basma'ak wala 'omri geet 'ala balak", translation: "Years have passed listening to you, never crossing your mind"),
                LyricLine(time: 14, text: "حبيت حنانك ومشتقالك يا حبيبي قرب لي", pronunciation: "Habbeit hananak w moshta'alak ya habibi 'arrab li", translation: "I loved your tenderness and miss you, come closer my love"),
                LyricLine(time: 22, text: "لو تعرف إيه بيحصل فيا لما بشوف عينيك", pronunciation: "Law te'raf eih beyehsal feya lamma bashoof 'eineik", translation: "If only you knew what happens to me when I see your eyes"),
                LyricLine(time: 30, text: "بنسى الدنيا وبنسى روحي وبهرب مني إليك", pronunciation: "Bansa el-donya w bansa roohi w bahrab menni eleyk", translation: "I forget the world and my soul, running from myself to you")
            ]
        ),
        SongItem(
            id: "awakher_al_shita",
            title: "Awakher Al Shita",
            artist: "Elissa",
            album: "Ayami Beek",
            duration: 268,
            artworkName: "elissa_awakher.jpg",
            remoteArtworkURL: nil,
            previewAudioURL: nil,
            bpm: 88,
            primaryColorHex: "#3E4B51",
            secondaryColorHex: "#1C2327",
            lyrics: [
                LyricLine(time: 0, text: "♪ أواخر الشتا - إليسا ♪", pronunciation: "Awakher Al Shita - Elissa", translation: "♪ Late Winter - Elissa ♪"),
                LyricLine(time: 7, text: "سهرنا يا ليل لحد الصبح ما يبان", pronunciation: "Seherna ya leil lehad el-sobh ma yeban", translation: "We stayed up all night until the morning light appeared"),
                LyricLine(time: 15, text: "في أواخر الشتا قبل اللي فات زي اليومين دول", pronunciation: "Fi awakher el-sheta 'abl elli fat zay el-youmein dol", translation: "In late winter before last, on days just like these")
            ]
        ),
        SongItem(
            id: "nase_shaklaha",
            title: "Nase Shaklaha",
            artist: "Tamer Ashour",
            album: "Khayali",
            duration: 234,
            artworkName: "tamer_ashour_nase.jpg",
            remoteArtworkURL: nil,
            previewAudioURL: nil,
            bpm: 94,
            primaryColorHex: "#4F463D",
            secondaryColorHex: "#24201C",
            lyrics: [
                LyricLine(time: 0, text: "♪ ناسي شكلها - تامر عاشور ♪", pronunciation: "Nase Shaklaha - Tamer Ashour", translation: "♪ Forgot How She Looks - Tamer Ashour ♪"),
                LyricLine(time: 6, text: "خلاص أنا مش فاكرها أنا حتى ناسي شكلها", pronunciation: "Khalas ana mesh fakerha ana hatta nasi shaklaha", translation: "I don't remember her anymore, I even forgot her face"),
                LyricLine(time: 14, text: "من النهاردة مفيش جراح واللي راح من عمري راح", pronunciation: "Men el-naharda mafeesh gerah welli rah men 'omri rah", translation: "From today no more wounds, what's gone is gone")
            ]
        )
    ]
}
