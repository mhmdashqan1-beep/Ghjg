import Foundation
import AVFoundation
import CoreHaptics
import Accelerate
import MediaPlayer

@MainActor
final class AudioHapticEngine: ObservableObject {
    @Published var currentSong: SongItem
    @Published var isPlaying: Bool = false
    @Published var currentTime: TimeInterval = 0
    @Published var volume: Float = 0.78
    @Published var isShuffle: Bool = false
    @Published var repeatMode: Int = 0
    @Published var isAutoplayInfinity: Bool = true
    @Published var isAutoMixEnabled: Bool = true
    @Published var showAutoMixPopover: Bool = false
    @Published var isMusicHapticsEnabled: Bool = true
    @Published var isLyricsMode: Bool = false
    @Published var showPronunciation: Bool = false
    @Published var showPronunciationBanner: Bool = false
    @Published var isSingMicEnabled: Bool = false
    @Published var vocalAttenuationLevel: Float = 0.25
    @Published var beatIntensity: CGFloat = 0.0

    private var hapticEngine: CHHapticEngine?
    private var timer: Timer?
    private var player: AVPlayer?

    init() {
        self.currentSong = MusicCatalog.shared.builtInSongs[0]
        setupAudioSession()
        setupCoreHaptics()
        setupRemoteTransportControls()
    }

    private func setupAudioSession() {
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.allowAirPlay, .allowBluetoothA2DP])
            try session.setActive(true)
        } catch {
            print("AVAudioSession error: \(error)")
        }
    }

    private func setupCoreHaptics() {
        guard CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        do {
            hapticEngine = try CHHapticEngine()
            try hapticEngine?.start()
            hapticEngine?.resetHandler = { [weak self] in
                try? self?.hapticEngine?.start()
            }
        } catch {
            print("CoreHaptics init error: \(error)")
        }
    }

    func triggerBeatHaptic(intensity: Float, sharpness: Float) {
        guard isMusicHapticsEnabled, CHHapticEngine.capabilitiesForHardware().supportsHaptics else { return }
        let intensityParam = CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity)
        let sharpnessParam = CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness)
        let transientEvent = CHHapticEvent(
            eventType: .hapticTransient,
            parameters: [intensityParam, sharpnessParam],
            relativeTime: 0
        )
        let continuousEvent = CHHapticEvent(
            eventType: .hapticContinuous,
            parameters: [
                CHHapticEventParameter(parameterID: .hapticIntensity, value: intensity * 0.65),
                CHHapticEventParameter(parameterID: .hapticSharpness, value: sharpness * 0.4)
            ],
            relativeTime: 0.02,
            duration: 0.12
        )
        do {
            let pattern = try CHHapticPattern(events: [transientEvent, continuousEvent], parameters: [])
            let player = try hapticEngine?.makePlayer(with: pattern)
            try player?.start(atTime: 0)
        } catch {
            let generator = UIImpactFeedbackGenerator(style: intensity > 0.75 ? .heavy : .medium)
            generator.impactOccurred(intensity: CGFloat(intensity))
        }
    }

    func selectSong(_ song: SongItem) {
        currentSong = song
        currentTime = 0
        if let urlStr = song.previewAudioURL, let url = URL(string: urlStr) {
            player = AVPlayer(url: url)
            player?.volume = volume
        } else {
            player = nil
        }
        play()
        updateNowPlayingInfo()
    }

    func togglePlayPause() {
        isPlaying ? pause() : play()
    }

    func play() {
        isPlaying = true
        player?.play()
        startSyncTimer()
        updateNowPlayingInfo()
    }

    func pause() {
        isPlaying = false
        player?.pause()
        timer?.invalidate()
        beatIntensity = 0
        updateNowPlayingInfo()
    }

    func seek(to time: TimeInterval) {
        currentTime = max(0, min(time, currentSong.duration))
        if let player = player {
            player.seek(to: CMTime(seconds: currentTime, preferredTimescale: 600))
        }
        triggerBeatHaptic(intensity: 0.6, sharpness: 0.7)
        updateNowPlayingInfo()
    }

    func nextTrack() {
        let list = MusicCatalog.shared.builtInSongs
        if let idx = list.firstIndex(of: currentSong) {
            let nextIdx = (idx + 1) % list.count
            selectSong(list[nextIdx])
        }
    }

    func previousTrack() {
        if currentTime > 4 {
            seek(to: 0)
            return
        }
        let list = MusicCatalog.shared.builtInSongs
        if let idx = list.firstIndex(of: currentSong) {
            let prevIdx = (idx - 1 + list.count) % list.count
            selectSong(list[prevIdx])
        }
    }

    private func startSyncTimer() {
        timer?.invalidate()
        let beatPeriod = 60.0 / max(60.0, currentSong.bpm)
        timer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { [weak self] _ in
            Task { @MainActor in
                guard let self = self, self.isPlaying else { return }
                self.currentTime += 0.05
                if self.currentTime >= self.currentSong.duration {
                    self.nextTrack()
                    return
                }
                let phase = self.currentTime.truncatingRemainder(dividingBy: beatPeriod) / beatPeriod
                if phase < 0.09 {
                    let isStrongBeat = Int(self.currentTime / beatPeriod) % 2 == 0
                    self.beatIntensity = isStrongBeat ? 1.0 : 0.68
                    self.triggerBeatHaptic(intensity: isStrongBeat ? 0.92 : 0.64, sharpness: isStrongBeat ? 0.80 : 0.50)
                } else {
                    self.beatIntensity = max(0.0, self.beatIntensity * 0.78)
                }
            }
        }
    }

    private func setupRemoteTransportControls() {
        let commandCenter = MPRemoteCommandCenter.shared()
        commandCenter.playCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.play() }
            return .success
        }
        commandCenter.pauseCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.pause() }
            return .success
        }
        commandCenter.nextTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.nextTrack() }
            return .success
        }
        commandCenter.previousTrackCommand.addTarget { [weak self] _ in
            Task { @MainActor in self?.previousTrack() }
            return .success
        }
    }

    private func updateNowPlayingInfo() {
        var info = [String: Any]()
        info[MPMediaItemPropertyTitle] = currentSong.title
        info[MPMediaItemPropertyArtist] = currentSong.artist
        info[MPMediaItemPropertyAlbumTitle] = currentSong.album
        info[MPMediaItemPropertyPlaybackDuration] = currentSong.duration
        info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = currentTime
        info[MPNowPlayingInfoPropertyPlaybackRate] = isPlaying ? 1.0 : 0.0
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }
}
