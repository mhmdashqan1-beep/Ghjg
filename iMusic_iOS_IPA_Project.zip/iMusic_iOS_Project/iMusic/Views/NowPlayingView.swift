import SwiftUI

struct NowPlayingView: View {
    @EnvironmentObject var engine: AudioHapticEngine
    @Environment(\.dismiss) var dismiss

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.25, green: 0.29, blue: 0.33), Color(red: 0.12, green: 0.14, blue: 0.17)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            VStack(spacing: 16) {
                Capsule()
                    .fill(Color.white.opacity(0.35))
                    .frame(width: 42, height: 5)
                    .padding(.top, 8)
                    .onTapGesture { dismiss() }

                // Header Row
                HStack(spacing: 14) {
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white.opacity(0.15))
                        .frame(width: 64, height: 64)
                        .scaleEffect(1.0 + engine.beatIntensity * 0.04)
                        .animation(.spring(response: 0.18, dampingFraction: 0.5), value: engine.beatIntensity)
                    VStack(alignment: .leading, spacing: 4) {
                        Text(engine.currentSong.title)
                            .font(.headline.weight(.bold))
                            .foregroundStyle(.white)
                        Text(engine.currentSong.artist)
                            .font(.subheadline)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    Spacer()
                    Button {} label: {
                        Image(systemName: "ellipsis")
                            .foregroundStyle(.white)
                            .padding(10)
                            .background(Color.white.opacity(0.12), in: Circle())
                    }
                }
                .padding(.horizontal, 24)

                // Top 4 Action Pills (Shuffle, Repeat, Infinity, AutoMix)
                if !engine.isLyricsMode {
                    HStack(spacing: 12) {
                        pillButton(icon: "shuffle", isActive: engine.isShuffle) {
                            engine.isShuffle.toggle()
                        }
                        pillButton(icon: "repeat", isActive: engine.repeatMode > 0) {
                            engine.repeatMode = (engine.repeatMode + 1) % 3
                        }
                        pillButton(icon: "infinity", isActive: engine.isAutoplayInfinity) {
                            engine.isAutoplayInfinity.toggle()
                        }
                        pillButton(icon: "circle.grid.cross.left.filled", isActive: engine.isAutoMixEnabled) {
                            engine.isAutoMixEnabled.toggle()
                            engine.showAutoMixPopover = true
                        }
                    }
                    .padding(.horizontal, 24)
                }

                // Main Content Area: Time-Synced Lyrics or Continue Playing Queue
                ScrollViewReader { proxy in
                    ScrollView(showsIndicators: false) {
                        VStack(alignment: .trailing, spacing: 22) {
                            ForEach(Array(engine.currentSong.lyrics.enumerated()), id: \.element.id) { index, line in
                                let isActive = isCurrentLine(index: index)
                                VStack(alignment: .trailing, spacing: 6) {
                                    if engine.showPronunciation {
                                        Text(line.pronunciation)
                                            .font(.subheadline.weight(.medium))
                                            .foregroundStyle(.white.opacity(isActive ? 0.85 : 0.35))
                                    }
                                    Text(line.text)
                                        .font(.system(size: 28, weight: .bold))
                                        .multilineTextAlignment(.trailing)
                                        .foregroundStyle(.white.opacity(isActive ? 1.0 : 0.28))
                                        .blur(radius: isActive ? 0 : 1.4)
                                        .scaleEffect(isActive ? 1.02 : 0.96, anchor: .trailing)
                                        .animation(.easeOut(duration: 0.25), value: isActive)
                                }
                                .frame(maxWidth: .infinity, alignment: .trailing)
                                .padding(.vertical, 8)
                                .padding(.horizontal, 14)
                                .background(
                                    RoundedRectangle(cornerRadius: 16)
                                        .fill(Color.white.opacity(isActive ? 0.08 : 0.0))
                                )
                                .id(line.id)
                                .onTapGesture {
                                    engine.seek(to: line.time)
                                }
                            }
                        }
                        .padding(.horizontal, 24)
                        .padding(.vertical, 20)
                    }
                    .onChange(of: engine.currentTime) { _, _ in
                        if let active = currentActiveLyric() {
                            withAnimation(.easeInOut(duration: 0.35)) {
                                proxy.scrollTo(active.id, anchor: .center)
                            }
                        }
                    }
                }

                // Pronunciation & Apple Music Sing Mic Controls
                HStack {
                    Button {
                        engine.showPronunciation.toggle()
                    } label: {
                        Image(systemName: "character.bubble.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(engine.showPronunciation ? .black : .white)
                            .frame(width: 40, height: 40)
                            .background(engine.showPronunciation ? Color.white : Color.white.opacity(0.15), in: Circle())
                    }
                    Spacer()
                    Button {
                        engine.isSingMicEnabled.toggle()
                    } label: {
                        Image(systemName: "mic.and.signal.meter.fill")
                            .font(.system(size: 16, weight: .semibold))
                            .foregroundStyle(engine.isSingMicEnabled ? .black : .white)
                            .frame(width: 40, height: 40)
                            .background(engine.isSingMicEnabled ? Color.white : Color.white.opacity(0.15), in: Circle())
                    }
                }
                .padding(.horizontal, 28)

                // Progress Bar + Music Haptics Badge
                VStack(spacing: 8) {
                    Slider(
                        value: Binding(
                            get: { engine.currentTime },
                            set: { engine.seek(to: $0) }
                        ),
                        in: 0...max(1, engine.currentSong.duration)
                    )
                    .tint(.white)

                    HStack {
                        Text(formatTime(engine.currentTime))
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.white.opacity(0.65))
                        Spacer()
                        Button {
                            engine.isMusicHapticsEnabled.toggle()
                        } label: {
                            HStack(spacing: 5) {
                                Image(systemName: "water.waves")
                                Text("Music Haptics")
                                    .font(.caption.weight(.semibold))
                            }
                            .foregroundStyle(.white.opacity(engine.isMusicHapticsEnabled ? 0.95 : 0.45))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 5)
                            .background(Color.white.opacity(engine.isMusicHapticsEnabled ? 0.18 : 0.07), in: RoundedRectangle(cornerRadius: 8))
                            .scaleEffect(1.0 + engine.beatIntensity * 0.06)
                        }
                        Spacer()
                        Text("-\(formatTime(max(0, engine.currentSong.duration - engine.currentTime)))")
                            .font(.caption.monospacedDigit())
                            .foregroundStyle(.white.opacity(0.65))
                    }
                }
                .padding(.horizontal, 28)

                // Main Transport Controls
                HStack(spacing: 56) {
                    Button { engine.previousTrack() } label: {
                        Image(systemName: "backward.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.white)
                    }
                    Button { engine.togglePlayPause() } label: {
                        Image(systemName: engine.isPlaying ? "pause.fill" : "play.fill")
                            .font(.system(size: 44))
                            .foregroundStyle(.white)
                    }
                    Button { engine.nextTrack() } label: {
                        Image(systemName: "forward.fill")
                            .font(.system(size: 30))
                            .foregroundStyle(.white)
                    }
                }
                .padding(.vertical, 6)

                // Volume Slider
                HStack(spacing: 12) {
                    Image(systemName: "speaker.fill")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(value: $engine.volume, in: 0...1)
                        .tint(.white)
                    Image(systemName: "speaker.wave.3.fill")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                }
                .padding(.horizontal, 28)

                // Bottom Bar: Lyrics, AirPlay, Queue
                HStack(spacing: 70) {
                    Button { engine.isLyricsMode.toggle() } label: {
                        Image(systemName: "quote.bubble.fill")
                            .font(.title3)
                            .foregroundStyle(engine.isLyricsMode ? .black : .white)
                            .frame(width: 44, height: 44)
                            .background(engine.isLyricsMode ? Color.white : Color.clear, in: Circle())
                    }
                    Button {} label: {
                        Image(systemName: "airplayaudio")
                            .font(.title3)
                            .foregroundStyle(.white.opacity(0.8))
                    }
                    Button { engine.isLyricsMode.toggle() } label: {
                        Image(systemName: "list.bullet")
                            .font(.title3)
                            .foregroundStyle(!engine.isLyricsMode ? .black : .white)
                            .frame(width: 44, height: 44)
                            .background(!engine.isLyricsMode ? Color.white : Color.clear, in: Circle())
                    }
                }
                .padding(.bottom, 12)
            }
        }
    }

    private func pillButton(icon: String, isActive: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 17, weight: .semibold))
                .foregroundStyle(isActive ? .black : .white)
                .frame(maxWidth: .infinity)
                .frame(height: 44)
                .background(isActive ? Color.white.opacity(0.9) : Color.white.opacity(0.14), in: Capsule())
        }
    }

    private func isCurrentLine(index: Int) -> Bool {
        let lyrics = engine.currentSong.lyrics
        guard index < lyrics.count else { return false }
        let start = lyrics[index].time
        let end = (index + 1 < lyrics.count) ? lyrics[index + 1].time : engine.currentSong.duration
        return engine.currentTime >= start && engine.currentTime < end
    }

    private func currentActiveLyric() -> LyricLine? {
        for i in 0..<engine.currentSong.lyrics.count {
            if isCurrentLine(index: i) {
                return engine.currentSong.lyrics[i]
            }
        }
        return nil
    }

    private func formatTime(_ sec: TimeInterval) -> String {
        let total = Int(max(0, sec))
        return String(format: "%d:%02d", total / 60, total % 60)
    }
}
