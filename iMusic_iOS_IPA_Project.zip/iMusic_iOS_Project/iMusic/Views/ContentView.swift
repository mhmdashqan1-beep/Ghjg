import SwiftUI

struct ContentView: View {
    @EnvironmentObject var engine: AudioHapticEngine
    @State private var selectedTab: Int = 4 // Default to Search/New like video
    @State private var showNowPlayingSheet: Bool = false
    @State private var searchText: String = ""

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 20) {
                            Text("Home")
                                .font(.system(size: 34, weight: .bold))
                                .padding(.horizontal)
                            ForEach(MusicCatalog.shared.builtInSongs) { song in
                                SongRowView(song: song) {
                                    engine.selectSong(song)
                                    showNowPlayingSheet = true
                                }
                            }
                        }
                        .padding(.bottom, 120)
                    }
                }
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }
                .tag(0)

                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 18) {
                            Text("New")
                                .font(.system(size: 34, weight: .bold))
                                .padding(.horizontal)
                            VStack(alignment: .leading, spacing: 6) {
                                Text("HUDDLE UP")
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(.secondary)
                                Text("It's official: JAY-Z is your Super Bowl LXI halftime headliner.")
                                    .font(.title3.weight(.medium))
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color.gray.opacity(0.25))
                                    .frame(height: 220)
                                    .overlay(
                                        Text("SUPER BOWL LXI • iMusic HALFTIME SHOW")
                                            .font(.headline)
                                    )
                            }
                            .padding(.horizontal)

                            Text("Best New Songs")
                                .font(.title2.weight(.bold))
                                .padding(.horizontal)

                            ForEach(MusicCatalog.shared.builtInSongs) { song in
                                SongRowView(song: song) {
                                    engine.selectSong(song)
                                    showNowPlayingSheet = true
                                }
                            }
                        }
                        .padding(.bottom, 120)
                    }
                }
                .tabItem {
                    Label("New", systemImage: "square.grid.2x2.fill")
                }
                .tag(1)

                Text("iMusic Radio")
                    .tabItem {
                        Label("Radio", systemImage: "dot.radiowaves.left.and.right")
                    }
                    .tag(2)

                Text("Your Library")
                    .tabItem {
                        Label("Library", systemImage: "music.note.list")
                    }
                    .tag(3)

                NavigationStack {
                    ScrollView {
                        VStack(alignment: .leading, spacing: 14) {
                            Text("Search")
                                .font(.system(size: 34, weight: .bold))
                                .padding(.horizontal)
                            HStack {
                                Image(systemName: "magnifyingglass")
                                    .foregroundStyle(.secondary)
                                TextField("Artists, Songs, Lyrics & More", text: $searchText)
                                if !searchText.isEmpty {
                                    Button {
                                        searchText = ""
                                    } label: {
                                        Image(systemName: "xmark.circle.fill")
                                            .foregroundStyle(.secondary)
                                    }
                                }
                            }
                            .padding(12)
                            .background(.ultraThinMaterial, in: Capsule())
                            .padding(.horizontal)

                            Text(searchText.isEmpty ? "Recently Searched" : "Top Results")
                                .font(.title3.weight(.bold))
                                .padding(.horizontal)

                            ForEach(filteredSongs) { song in
                                SongRowView(song: song) {
                                    engine.selectSong(song)
                                    showNowPlayingSheet = true
                                }
                            }
                        }
                        .padding(.bottom, 120)
                    }
                }
                .tabItem {
                    Label("Search", systemImage: "magnifyingglass")
                }
                .tag(4)
            }
            .tint(.blue)

            // Floating MiniPlayer
            Button {
                showNowPlayingSheet = true
            } label: {
                HStack(spacing: 12) {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.gray.opacity(0.35))
                        .frame(width: 44, height: 44)
                        .overlay(Image(systemName: "music.note").foregroundStyle(.white))
                    VStack(alignment: .leading, spacing: 2) {
                        Text(engine.currentSong.title)
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.primary)
                        Text(engine.currentSong.artist)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    Button {
                        engine.togglePlayPause()
                    } label: {
                        Image(systemName: engine.isPlaying ? "pause.fill" : "play.fill")
                            .font(.title3)
                            .foregroundStyle(.primary)
                    }
                    .padding(.horizontal, 6)
                    Button {
                        engine.nextTrack()
                    } label: {
                        Image(systemName: "forward.fill")
                            .font(.title3)
                            .foregroundStyle(.primary)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(.ultraThinMaterial, in: Capsule())
                .padding(.horizontal, 12)
                .padding(.bottom, 58)
            }
            .buttonStyle(.plain)
        }
        .fullScreenCover(isPresented: $showNowPlayingSheet) {
            NowPlayingView()
                .environmentObject(engine)
        }
    }

    private var filteredSongs: [SongItem] {
        guard !searchText.trimmingCharacters(in: .whitespaces).isEmpty else {
            return MusicCatalog.shared.builtInSongs
        }
        let q = searchText.lowercased()
        return MusicCatalog.shared.builtInSongs.filter {
            $0.title.lowercased().contains(q) ||
            $0.artist.lowercased().contains(q) ||
            $0.lyrics.contains(where: { $0.text.contains(q) })
        }
    }
}

struct SongRowView: View {
    let song: SongItem
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 14) {
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.gray.opacity(0.3))
                    .frame(width: 56, height: 56)
                    .overlay(Image(systemName: "music.quarternote.3").foregroundStyle(.white.opacity(0.8)))
                VStack(alignment: .leading, spacing: 4) {
                    Text(song.title)
                        .font(.body.weight(.medium))
                        .foregroundStyle(.primary)
                    Text("Song · \(song.artist)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "ellipsis")
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal)
            .padding(.vertical, 4)
        }
        .buttonStyle(.plain)
    }
}
