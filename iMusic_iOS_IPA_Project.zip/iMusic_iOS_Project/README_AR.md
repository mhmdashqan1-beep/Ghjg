# مشروع تطبيق iMusic للأيفون (SwiftUI + CoreHaptics + Synced Lyrics)

يحتوي هذا الأرشيف على السورس كود الكامل والحقيقي لتطبيق **iMusic** لنظام iOS المكتوب بلغة **Swift 5 / SwiftUI** مع محرك الاهتزاز الحقيقي **CoreHaptics (`CHHapticEngine`)** ومزامنة الكلمات اللحظية (**Time-Synced Lyrics**) وخاصية **AutoMix** و **Sing Vocal Reducer**.

## كيف تستخرج ملف `iMusic.ipa` جاهز للتوقيع والتثبيت بدون الحاجة لجهاز Mac؟

بما أن ملفات `.ipa` التنفيذية تتطلب مترجم Apple Xcode SDK الخاص بنظام macOS، فقد قمنا بإعداد ملف بناء تلقائي كامل داخل المشروع (`.github/workflows/build-ipa.yml`):

1. أنشئ مستودعاً مجانياً (Repository) على حسابك في **GitHub**.
2. ارفع محتويات هذا المجلد إلى المستودع.
3. ادخل إلى تبويب **Actions** في مستودعك واضغط على **Build Unsigned iMusic IPA**.
4. خلال دقيقتين فقط، سيقوم خادم macOS ببناء التطبيق وإخراج ملف **`iMusic.ipa`** جاهزاً للتحميل المباشر.
5. قم بتوقيع ملف `iMusic.ipa` وتثبيته على الأيفون باستخدام أداة التوقيع المفضلة لديك (**ESign**، **Scarlet**، **Feather**، **Sideloadly**، أو **AltStore**).
